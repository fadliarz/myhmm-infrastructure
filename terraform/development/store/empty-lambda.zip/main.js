exports.handler = async () => {
  console.log('Empty lambda...');
};